#include "CrazyGuitar.h"

// Unreal Includes
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE(FDefaultGameModuleImpl, CrazyGuitar, "CrazyGuitar");